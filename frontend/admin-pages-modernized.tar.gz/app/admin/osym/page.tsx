'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface ExamType {
  id: string;
  code: string;
  name_tr: string;
  short_name: string;
}

interface OsymTopic {
  id: string;
  official_name: string;
  subject_name: string;
  exam_type_id: string;
  related_grade_levels: number[];
  published_year: number;
  exam_types: {
    short_name: string;
  };
}

export default function AdminOsymPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [examTypes, setExamTypes] = useState<ExamType[]>([]);
  const [osymTopics, setOsymTopics] = useState<OsymTopic[]>([]);
  const [selectedExamType, setSelectedExamType] = useState('');
  
  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showBulkUpload, setShowBulkUpload] = useState(false);
  
  // Add form
  const [newOsym, setNewOsym] = useState({
    exam_type_id: '',
    official_name: '',
    subject_name: '',
    related_grade_levels: [] as number[],
    published_year: 2024
  });
  
  // Bulk upload
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadResult, setUploadResult] = useState<any>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const accessToken = localStorage.getItem('access_token');

      // Mock exam types (gerçek API'den gelecek)
      setExamTypes([
        { id: '1', code: 'TYT', name_tr: 'TYT', short_name: 'TYT' },
        { id: '2', code: 'AYT', name_tr: 'AYT', short_name: 'AYT' },
      ]);

      // ÖSYM topics'leri çek
      const response = await fetch('http://localhost:8000/api/v1/osym/topics', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setOsymTopics(data.osym_topics || []);
      }

    } catch (err) {
      console.error('Data fetch hatası:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddOsym = async () => {
    try {
      const accessToken = localStorage.getItem('access_token');
      
      const response = await fetch('http://localhost:8000/api/v1/admin/osym-topics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify(newOsym)
      });

      if (response.ok) {
        alert('✅ ÖSYM konusu eklendi!');
        setShowAddModal(false);
        fetchData();
      } else {
        alert('❌ Hata oluştu!');
      }
    } catch (err) {
      console.error('Add ÖSYM topic hatası:', err);
    }
  };

  const handleBulkUpload = async () => {
    if (!uploadFile) {
      alert('Lütfen bir dosya seçin!');
      return;
    }

    setUploading(true);
    setUploadResult(null);

    try {
      const accessToken = localStorage.getItem('access_token');
      const formData = new FormData();
      formData.append('file', uploadFile);

      const response = await fetch('http://localhost:8000/api/v1/admin/osym-topics/bulk-upload', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken}` },
        body: formData
      });

      if (response.ok) {
        const result = await response.json();
        setUploadResult(result);
        
        if (result.success) {
          setTimeout(() => {
            setShowBulkUpload(false);
            fetchData();
          }, 2000);
        }
      } else {
        const error = await response.json();
        alert(`Hata: ${error.detail}`);
      }
    } catch (err) {
      console.error('Upload hatası:', err);
      alert('Bir hata oluştu!');
    } finally {
      setUploading(false);
    }
  };

  const filteredTopics = selectedExamType
    ? osymTopics.filter(t => t.exam_type_id === selectedExamType)
    : osymTopics;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">🎯 ÖSYM Konu Yönetimi</h1>
            <p className="text-sm text-gray-500">Resmi sınav konuları ve MEB eşleştirme</p>
          </div>
          
          <button 
            onClick={() => router.push('/student/dashboard')}
            className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-800 transition"
          >
            ← Geri Dön
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Controls */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex gap-4 items-center">
            <h2 className="text-xl font-bold text-gray-800">ÖSYM Resmi Konuları</h2>
            
            <select
              value={selectedExamType}
              onChange={(e) => setSelectedExamType(e.target.value)}
              className="px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Tüm Sınavlar ({osymTopics.length})</option>
              {examTypes.map(type => (
                <option key={type.id} value={type.id}>
                  {type.short_name}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={() => setShowBulkUpload(true)}
              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-semibold"
            >
              📤 Toplu Yükle
            </button>
            
            <button
              onClick={() => setShowAddModal(true)}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold"
            >
              ➕ Tekli Ekle
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <tr>
                <th className="px-6 py-4 text-left font-semibold">ÖSYM Resmi Adı</th>
                <th className="px-6 py-4 text-left font-semibold">Ders</th>
                <th className="px-6 py-4 text-center font-semibold">Sınav</th>
                <th className="px-6 py-4 text-center font-semibold">Sınıflar</th>
                <th className="px-6 py-4 text-center font-semibold">Yıl</th>
              </tr>
            </thead>
            <tbody>
              {filteredTopics.length > 0 ? (
                filteredTopics.map((topic, index) => (
                  <tr key={topic.id} className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'} hover:bg-blue-50 transition`}>
                    <td className="px-6 py-4 font-semibold text-gray-800">{topic.official_name}</td>
                    <td className="px-6 py-4 text-gray-600">{topic.subject_name}</td>
                    <td className="px-6 py-4 text-center">
                      <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full font-semibold text-sm">
                        {topic.exam_types.short_name}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center text-gray-600">
                      {topic.related_grade_levels.join(', ')}. sınıf
                    </td>
                    <td className="px-6 py-4 text-center text-gray-600">
                      {topic.published_year}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    <div className="text-6xl mb-4">📋</div>
                    <p className="text-lg font-semibold">Henüz ÖSYM konusu eklenmemiş</p>
                    <p className="text-sm mt-2">Toplu yükleme ile Excel'den ekleyin</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </main>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-2xl w-full">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">➕ Yeni ÖSYM Konusu Ekle</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Sınav Türü</label>
                <select
                  value={newOsym.exam_type_id}
                  onChange={(e) => setNewOsym({...newOsym, exam_type_id: e.target.value})}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Seçin</option>
                  {examTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.name_tr}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">ÖSYM Resmi Adı</label>
                <input
                  type="text"
                  value={newOsym.official_name}
                  onChange={(e) => setNewOsym({...newOsym, official_name: e.target.value})}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Örn: Limit ve Süreklilik"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Ders Adı</label>
                <input
                  type="text"
                  value={newOsym.subject_name}
                  onChange={(e) => setNewOsym({...newOsym, subject_name: e.target.value})}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Örn: AYT Matematik"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">İlgili Sınıflar (virgülle)</label>
                <input
                  type="text"
                  placeholder="Örn: 11, 12"
                  onChange={(e) => {
                    const grades = e.target.value.split(',').map(g => parseInt(g.trim())).filter(g => !isNaN(g));
                    setNewOsym({...newOsym, related_grade_levels: grades});
                  }}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="flex gap-4 mt-6">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-semibold"
              >
                İptal
              </button>
              <button
                onClick={handleAddOsym}
                className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
                disabled={!newOsym.exam_type_id || !newOsym.official_name}
              >
                Ekle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Upload Modal */}
      {showBulkUpload && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-2xl w-full">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">📤 Toplu ÖSYM Konusu Yükle</h3>
            
            {!uploadResult ? (
              <>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center mb-6 hover:border-blue-500 transition">
                  <input
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                    className="hidden"
                    id="excel-upload"
                  />
                  <label htmlFor="excel-upload" className="cursor-pointer">
                    <div className="text-6xl mb-4">📄</div>
                    <p className="text-lg font-semibold text-gray-700 mb-2">
                      {uploadFile ? uploadFile.name : 'Excel dosyası seçin'}
                    </p>
                    <p className="text-sm text-gray-500">
                      .xlsx, .xls veya .csv formatında
                    </p>
                  </label>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => {
                      setShowBulkUpload(false);
                      setUploadFile(null);
                    }}
                    className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-semibold"
                    disabled={uploading}
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleBulkUpload}
                    className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold disabled:bg-gray-400"
                    disabled={!uploadFile || uploading}
                  >
                    {uploading ? '⏳ Yükleniyor...' : '📤 Yükle'}
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6 mb-6">
                  <h4 className="font-bold text-lg mb-3 text-green-900">
                    ✅ Yükleme Tamamlandı!
                  </h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white rounded-lg p-4">
                      <p className="text-sm text-gray-600 mb-1">Başarılı:</p>
                      <p className="text-3xl font-bold text-green-600">{uploadResult.success_count}</p>
                    </div>
                    <div className="bg-white rounded-lg p-4">
                      <p className="text-sm text-gray-600 mb-1">Hatalı:</p>
                      <p className="text-3xl font-bold text-red-600">{uploadResult.error_count}</p>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setShowBulkUpload(false);
                    setUploadFile(null);
                    setUploadResult(null);
                  }}
                  className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
                >
                  Kapat
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
