import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export async function middleware(req: NextRequest) {
  // Backend JWT token'ı cookie'den veya header'dan kontrol et
  // (localStorage server-side'da çalışmaz, o yüzden cookie kullanmalıyız)
  
  const token = req.cookies.get('access_token')?.value;
  const isProtectedRoute = req.nextUrl.pathname.startsWith('/student');
  const isLoginPage = req.nextUrl.pathname === '/login';

  // Protected route'a token olmadan girilmeye çalışılıyor
  if (isProtectedRoute && !token) {
    return NextResponse.redirect(new URL('/login', req.url));
  }

  // Token varken login sayfasına girilmeye çalışılıyor
  if (isLoginPage && token) {
    return NextResponse.redirect(new URL('/student/dashboard', req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/student/:path*', '/login'],
}
