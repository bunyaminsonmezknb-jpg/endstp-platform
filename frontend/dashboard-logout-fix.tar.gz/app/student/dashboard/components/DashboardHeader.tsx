'use client';

import React from 'react';
import { useRouter } from 'next/navigation';

interface DashboardHeaderProps {
  studentName: string;
  streak: number;
}

export default function DashboardHeader({ studentName, streak }: DashboardHeaderProps) {
  const router = useRouter();

  const handleLogout = () => {
    // LocalStorage temizle
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    
    // Cookie temizle
    document.cookie = 'access_token=; path=/; max-age=0';
    
    // Login'e yönlendir
    router.push('/login');
  };

  return (
    <div className="bg-white rounded-2xl p-5 mb-5 flex justify-between items-center shadow-lg">
      <div className="text-2xl font-bold text-end-purple">End.STP</div>
      
      <div className="flex items-center gap-4">
        <div className="bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2 rounded-full font-semibold text-sm flex items-center gap-2 animate-pulse">
          🔥 {streak} Günlük Seri
        </div>
        
        <span className="text-gray-600 hidden md:inline">
          Hoş geldin, <strong>{studentName}</strong>
        </span>
        
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-end-purple to-end-purple-dark flex items-center justify-center text-white font-bold">
          {studentName.split(' ').map(n => n[0]).join('')}
        </div>

        <button
          onClick={handleLogout}
          className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
        >
          🚪 Çıkış
        </button>
      </div>
    </div>
  );
}
