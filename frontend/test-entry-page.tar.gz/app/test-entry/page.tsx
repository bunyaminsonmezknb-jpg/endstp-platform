'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Subject {
  id: string;
  code: string;
  name_tr: string;
  icon: string;
  color: string;
}

interface Topic {
  id: string;
  code: string;
  name_tr: string;
}

export default function TestEntryPage() {
  const router = useRouter();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form state
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('');
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [wrongCount, setWrongCount] = useState<number>(0);
  const [emptyCount, setEmptyCount] = useState<number>(0);

  // Hesaplanan değerler
  const totalQuestions = correctCount + wrongCount + emptyCount;
  const net = correctCount - (wrongCount / 4);
  const successRate = totalQuestions > 0 ? (correctCount / totalQuestions) * 100 : 0;

  // Subjects yükle
  useEffect(() => {
    fetchSubjects();
  }, []);

  // Subject değişince topics yükle
  useEffect(() => {
    if (selectedSubject) {
      fetchTopics(selectedSubject);
    } else {
      setTopics([]);
      setSelectedTopic('');
    }
  }, [selectedSubject]);

  const fetchSubjects = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/v1/subjects');
      const data = await response.json();
      setSubjects(data);
    } catch (err) {
      console.error('Subjects fetch error:', err);
      setError('Dersler yüklenemedi');
    }
  };

  const fetchTopics = async (subjectId: string) => {
    try {
      const response = await fetch(`http://localhost:8000/api/v1/subjects/${subjectId}/topics`);
      const data = await response.json();
      setTopics(data);
    } catch (err) {
      console.error('Topics fetch error:', err);
      setError('Konular yüklenemedi');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(false);

    // Validation
    if (!selectedSubject || !selectedTopic) {
      setError('Lütfen ders ve konu seçin');
      setLoading(false);
      return;
    }

    if (totalQuestions === 0) {
      setError('Lütfen en az bir soru sayısı girin');
      setLoading(false);
      return;
    }

    try {
      // User bilgisini localStorage'dan al
      const userStr = localStorage.getItem('user');
      if (!userStr) {
        setError('Kullanıcı bilgisi bulunamadı. Lütfen tekrar giriş yapın.');
        setLoading(false);
        return;
      }

      const user = JSON.parse(userStr);
      const token = localStorage.getItem('access_token');

      // Subject ve Topic isimlerini bul
      const subject = subjects.find(s => s.id === selectedSubject);
      const topic = topics.find(t => t.id === selectedTopic);

      const response = await fetch('http://localhost:8000/api/v1/test-results', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          student_id: user.id,
          subject: subject?.name_tr || '',
          topic: topic?.name_tr || '',
          correct_count: correctCount,
          wrong_count: wrongCount,
          empty_count: emptyCount,
          net: parseFloat(net.toFixed(2)),
          success_rate: parseFloat(successRate.toFixed(2)),
          entry_timestamp: new Date().toISOString(),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Test kaydedilemedi');
      }

      // Başarılı!
      setSuccess(true);
      
      // Formu temizle
      setTimeout(() => {
        setSelectedSubject('');
        setSelectedTopic('');
        setCorrectCount(0);
        setWrongCount(0);
        setEmptyCount(0);
        setSuccess(false);
      }, 2000);

    } catch (err: any) {
      console.error('Test entry error:', err);
      setError(err.message || 'Test kaydı sırasında hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-blue-50 to-purple-50 p-5">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-800">📝 Test Girişi</h1>
          <button
            onClick={() => router.push('/student/dashboard')}
            className="px-4 py-2 bg-white rounded-lg shadow hover:shadow-lg transition-all"
          >
            ← Dashboard'a Dön
          </button>
        </div>

        {/* Success Message */}
        {success && (
          <div className="bg-green-100 border-2 border-green-500 text-green-800 px-6 py-4 rounded-2xl mb-6 animate-pulse">
            <div className="flex items-center gap-3">
              <span className="text-3xl">✅</span>
              <div>
                <div className="font-bold">Test başarıyla kaydedildi!</div>
                <div className="text-sm">Dashboard'da görebilirsiniz.</div>
              </div>
            </div>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="bg-red-100 border-2 border-red-500 text-red-800 px-6 py-4 rounded-2xl mb-6">
            <div className="flex items-center gap-3">
              <span className="text-3xl">❌</span>
              <div>
                <div className="font-bold">Hata!</div>
                <div className="text-sm">{error}</div>
              </div>
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-2xl p-8">
          {/* Subject Dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              📚 Ders
            </label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              required
            >
              <option value="">Ders seçin...</option>
              {subjects.map((subject) => (
                <option key={subject.id} value={subject.id}>
                  {subject.icon} {subject.name_tr}
                </option>
              ))}
            </select>
          </div>

          {/* Topic Dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              📖 Konu
            </label>
            <select
              value={selectedTopic}
              onChange={(e) => setSelectedTopic(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              disabled={!selectedSubject || topics.length === 0}
              required
            >
              <option value="">
                {!selectedSubject ? 'Önce ders seçin...' : 'Konu seçin...'}
              </option>
              {topics.map((topic) => (
                <option key={topic.id} value={topic.id}>
                  {topic.name_tr}
                </option>
              ))}
            </select>
          </div>

          {/* Soru Sayıları */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {/* Doğru */}
            <div>
              <label className="block text-sm font-semibold text-green-700 mb-2">
                ✅ Doğru
              </label>
              <input
                type="number"
                min="0"
                value={correctCount}
                onChange={(e) => setCorrectCount(parseInt(e.target.value) || 0)}
                className="w-full px-4 py-3 border-2 border-green-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent text-center text-xl font-bold"
              />
            </div>

            {/* Yanlış */}
            <div>
              <label className="block text-sm font-semibold text-red-700 mb-2">
                ❌ Yanlış
              </label>
              <input
                type="number"
                min="0"
                value={wrongCount}
                onChange={(e) => setWrongCount(parseInt(e.target.value) || 0)}
                className="w-full px-4 py-3 border-2 border-red-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent text-center text-xl font-bold"
              />
            </div>

            {/* Boş */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                ⭕ Boş
              </label>
              <input
                type="number"
                min="0"
                value={emptyCount}
                onChange={(e) => setEmptyCount(parseInt(e.target.value) || 0)}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent text-center text-xl font-bold"
              />
            </div>
          </div>

          {/* Hesaplanan Değerler */}
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-6 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-1">📊 Net</div>
                <div className="text-3xl font-bold text-purple-600">
                  {net.toFixed(2)}
                </div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-1">📈 Başarı Oranı</div>
                <div className="text-3xl font-bold text-blue-600">
                  %{successRate.toFixed(1)}
                </div>
              </div>
            </div>
            <div className="text-center mt-3 text-xs text-gray-500">
              Toplam {totalQuestions} soru
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading || !selectedSubject || !selectedTopic || totalQuestions === 0}
            className={`w-full py-4 rounded-xl text-white font-bold text-lg transition-all ${
              loading || !selectedSubject || !selectedTopic || totalQuestions === 0
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 to-blue-600 hover:scale-105 shadow-lg'
            }`}
          >
            {loading ? '⏳ Kaydediliyor...' : '💾 Test Sonucunu Kaydet'}
          </button>
        </form>
      </div>
    </div>
  );
}
