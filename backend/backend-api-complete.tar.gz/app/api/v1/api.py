"""
API v1 Router
Tüm endpoint'leri buradan topla
"""

from fastapi import APIRouter
from app.api.v1.endpoints import admin_osym, admin_exams

api_router = APIRouter()

# Admin ÖSYM endpoints
api_router.include_router(
    admin_osym.router,
    prefix="",
    tags=["admin-osym"]
)

# Admin Exams endpoints
api_router.include_router(
    admin_exams.router,
    prefix="",
    tags=["admin-exams"]
)
